import emailRecieve
import task
import emailsend
import sys
import time

if __name__ == '__main__':
    hold = []
    print('|----------------------------------------------------------------------|\n')
    print('|         WELCOME TO ERROR BY NIGHT"S SYSTEM                           |\n')
    print('|----------------------------------------------------------------------|\n')
    print("|                            Options:                                  |\n")
    print("|    --> 1 READ ALL NEW EMAILS                                         |\n")
    print("|    --> 2 REPLY TO ALL EMAILS                                         |\n")
    print("|    --> 3 GENERATE TASKS FROM FORM RESPONSES                          |\n")
    print("|    --> 4 VIEW EMPLOYEES'S ASSIGNED TASKS                             |\n")
    print("|    --> 5 EXIT THE SYSTEM                                             |\n")
    print('|----------------------------------------------------------------------|\n')
    option = input("Select one of the above options: ")
    cont = True

    while cont:
        if option is '1':
            emailRecieve.readEmail()
            time.sleep(1)
        elif option is '2':
            emailsend.readEmailFromFile()
            time.sleep(1)
        elif option is '3':
            hold = task.createTask()
            time.sleep(1)
        elif option is '4':
            task.viewAssignedTasks(hold)
            key = input("Press any key to continue")
            time.sleep(2)
        elif option is '5':
            print("\n\n<<<<<<<<<<THANK YOU FOR USING ERROR BY NIGHT'S SYSTEM>>>>>>>>>>>>")
            cont = False
            print("The system will now close.")
            time.sleep(2)
            sys.exit()
        else:
            print("INVALID OPTION!!!! Wait a few seconds to try again.")
            time.sleep(3)
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
        print('|----------------------------------------------------------------------|\n')
        print("|                            Options:                                  |\n")
        print("|    --> 1 READ ALL NEW EMAILS                                         |\n")
        print("|    --> 2 REPLY TO ALL EMAILS                                         |\n")
        print("|    --> 3 GENERATE TASKS FROM FORM RESPONSES                          |\n")
        print("|    --> 4 VIEW EMPLOYEES'S ASSIGNED TASKS                             |\n")
        print("|    --> 5 EXIT THE SYSTEM                                             |\n")
        print('|----------------------------------------------------------------------|\n')
        option = input("Select one of the above options: \n")
        time.sleep(1)
        print("\n\n\n\n\n")


