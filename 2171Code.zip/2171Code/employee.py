import task
class Employee:
    def __init__(self, nm, jbs=None):
        self.name = nm
        if jbs == None:
            self.jobs = []
        else:
            self.jobs = jbs

    def getName(self):
        return self.name

    def getJobs(self):
        return self.jobs

    def taskAssignment(self, Task):
        if isinstance(Task, task):
            self.jobs.append(Task)
        else:
            print("Input attribute is not Task type.")

    def removeTask(self, Task):
        self.jobs.remove(Task)

    def printTasks(self):
        for job in self.jobs:
            print(job.getCategory())

    @classmethod
    def isEmployee(cls, val):
        return isinstance(val, Employee)


class Manager(Employee):

    def __init__(self, nm):
        super().__init__(nm)

    def internalTaskAssignment(self, Task, employee):
        if employee.isEmployee():
            employee.taskAssignment(Task)
        else:
            print("Error, this is not an Employee!!!!")

    @classmethod
    def isManager(cls, val):
        return isinstance(val, Manager)


emp1 = Employee("Dwight")
emp2 = Employee("Wei Te")
mang1 = Manager("K-C")

print(Manager.isManager(emp1))
print(Employee.isEmployee(mang1))
try:
    print(emp1.internalTaskAssignment(emp2, emp1))
except AttributeError:
    print("This employee is NOT a Manager")
print(mang1.getJobs())

