import csv
import os

savePath = r"D:\School\Docs\2171Code\Emails\FormResults"

def readDataFromFile():
	data = []
	header = []
	h = []
	print(os.listdir(savePath))
	option = int(input("Enter the number of the file you want to open: "))
	fileName = os.listdir(savePath)[option-1]
	completePath = os.path.join(savePath,fileName)
	with open(completePath, mode='r') as csv_file:
		csv_reader = csv.DictReader(csv_file)
		line_count = 0
		for row in csv_reader:
			h += [list(zip(row.keys(),row.values()))]
	
	#for line in h:
		#print("Response: ")
		#for question in line:
			#print(question)
		#print("\n")

	return h
#readDataFromFile()
