class category:
    #Attributes
    elst = ["fabric", "containers", "event"]
    tlst = ["print","Print","Design","Cater", "design", "cater"]
    type = None

    def __init__(self, typ):
        if typ is None:
            self.type = "Misc"
        else:
            self.type = typ

    def setCategory(self, newType):
        self.type = newType

    def getCategory(self):
        return self.type

    def __str__(self):
        return "The overall category is --> ", self.type


class EmailCategory(category):

    def __init__(self, typ=None):
        if typ is None:
            super().__init__()
        elif typ in category.elst:
            super().__init__(typ)
        else:
            super().__init__()

    def __str__(self):
        return "The category of the Email is --> ", self.type


class TaskCategory(category):

	def __init__(self, typ=None):
		if typ is None:
			super().__init__()
		elif typ in category.tlst:
			super().__init__(typ)
		else:
			super().__init__()

	def __str__(self):
		return "The category of the Task is --> ", self.type

	def getKeywords():
		return self.tlst

