class Status:
    type_lst = ["Pending", "Complete", "Inprogress"]
    type = None

    def __init__(self, typ=None):
        if typ is None or typ not in self.type_lst:
            self.type = "No Progress"
        else:
            self.type = typ

    def setStatus(self, typ):
        if typ in self.type_lst:
            self.type = typ
        else:
            print("Invalid Status")

    def __str__(self):
        return "The status is --> ", self.type