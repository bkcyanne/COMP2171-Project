#I want to save the emails in folders based on the sender.

import emailsend
import email
import imaplib
import time
import datetime
import os

EMAIL = 'marlontestemail1@gmail.com'
PASSWORD = 'marlontest'
SERVER = 'imap.gmail.com'

#savePath = '/home/djm_9/Desktop/PythonEmails/Emails'#To save the emails in a subfolder
savePath = r"D:\School\Docs\2171Code\Emails"
attachmentSavePath = r'D:\School\Docs\2171Code\Emails\Attachments'


def downloadAttachments(emailMsg, pathToSaveFile):
    """
    Save Attachments to pathToSaveFile (Example: pathToSaveFile = "C:\\Program Files\\")
    """
    att_path_list = []
    for part in emailMsg.walk():
        # multipart are just containers, so we skip them
        if part.get_content_maintype() == 'multipart':
            continue

        # is this part an attachment ?
        if part.get('Content-Disposition') is None:
            continue

        filename = part.get_filename()

        att_path = os.path.join(pathToSaveFile, filename)
        print("Downloading attachment")
        #Check if its already there
        if not os.path.isfile(att_path) :
            # finally write the stuff
            fp = open(att_path, 'wb')
            fp.write(part.get_payload(decode=True))
            fp.close()
        att_path_list.append(att_path)
    return att_path_list

def readEmail():
	#Connect to the server and go to its inbox
	mail =imaplib.IMAP4_SSL(SERVER)
	mail.login(EMAIL,PASSWORD)

	#We choose the inbox but you can select others
	mail.select('inbox')

	#We'll search using the ALL criteria to retrieve every message inside the inbox.
	#It will return with its status and a list of ids
	status, data = mail.search(None, 'UnSeen')

	uids = [int(s) for s in data[0].split()]
	if uids:
		uid_max = max(uids)
	#The list returned is a list of bytes separated by white spaces on this format: [b'1 2 3',b'4 5 6']
	#so, to separate it first we create an empty list
	mail_ids = []

	#Then we go through the list splitting its blocks of bytes and appending to the mail_ids list
	for block in data:
		#The split function called without parameter transforms the text or bytes into a list using as spearator the white spaces
		# b '1 2 3'.split() => [b'1', b'2',b'3']
		mail_ids += block.split()
		

	#now for every id we'll fetch the email to extract its content
	for i in mail_ids:
		#The fetch function fetch the email given its id and the format you want the message to be
		status, data = mail.fetch(i,'(RFC822)')

		#The content data at the '(RFC822)' format comes on a list with a tuple with header, content and the closing byte b
		for response_part in data:
			
			#So if its a tuple...
			if isinstance(response_part, tuple):
				#We go for the content at its second element skipping the header at the first and the closing at the third
				message = email.message_from_bytes(response_part[1])

				#with the content we can extract the info about who sent the message and its subject
				mail_from = message['from']
				mail_subject = message['subject']

				#Getting the date of the email
				mail_date = message['Date']
				
				#Converting the date returned into a readable format
				date_tuple = email.utils.parsedate_tz(mail_date)
				
				if date_tuple:
					local_date = datetime.datetime.fromtimestamp(email.utils.mktime_tz(date_tuple))
					mail_date = local_date.strftime("%a, %d %b %Y %H_%M_%S")

				#Then for the text we have a little more work to do because it can be in plain text or multipart 
				#if its not plain text we need to separate the message from its annexes to get the text
				if message.is_multipart():
					mail_content = ''

					#On multipart we have the text message and another things like annex, and html version of the message but
					#in that case we loop through of the email payload

					for part in message.get_payload():

						#Function to download attachments in emails
						downloadAttachments(message,attachmentSavePath)

						#If the content type is text/plain we extract it
						if part.get_content_type() == 'text/plain':
							mail_content += part.get_payload()
						
				else:
					#If the message isn't multipart, just extract it
					message1 = email.message_from_string(message)
					mail_content = message1.get_payload()

				
				message.Unread = False #should change the flag
				mail.store(i,'+FLAGS','\Seen')

				
				print("\n\nNew Email Recieved\n\n\n")

				#And then let's show its result
				print('From: ' + mail_from)
				print('Subject:' + mail_subject)
				print("Local Date: " + mail_date)
				print('Content: '+ mail_content)

				print("\n\n")

				#Saving the email in a file.
				fileName = mail_from.split("<")[0]
				fileName += mail_date
				fileName += ".txt"

				#All files are text files
				completePath = os.path.join(savePath, fileName)
				print("Writing to: " + completePath)
				f = open(completePath, "w")
				
				#Format of how the file is Date of Email -> Sender -> Subject -> Content
				f.write("Date: " + str(mail_date)+"\n")
				f.write("Message from: " + str(mail_from) +"\n")
				f.write("Subject: " + str(mail_subject) + "\n")
				f.write("Content: " + str(mail_content))
				f.close()

				print("File writing done")

				print("\n\n\n")
				print("--------------------------------------------------------------------------\n\n")
				time.sleep(1)

	mail.logout()
	if len(uids) == 0:
		print("No new emails recieved.")
	else:
		if int(input("Do you want to reply to all the emails now? Press 1 for yes and 2 for no: ")) == 1:
				emailsend.readEmailFromFile()
				print("\n\nWaiting on new emails")
		else:
			print("Waiting on new emails")
readEmail()