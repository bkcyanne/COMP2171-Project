import time
import datetime
import os
import smtplib
from email.mime.text import MIMEText


keyWords = {"Inquiries":"https://forms.gle/V8WujU8tYjGhygts9", "inquiries":"https://forms.gle/V8WujU8tYjGhygts9","Print":"https://forms.gle/qFmT9dh5Jdhzispp9","print":"https://forms.gle/qFmT9dh5Jdhzispp9","Quotation":"https://forms.gle/j8sH34UgrAdjEcmC61","quotation":"https://forms.gle/j8sH34UgrAdjEcmC6","Default":"https://forms.gle/V8WujU8tYjGhygts9"}

savePath = r"D:\School\Docs\\2171Code\Emails"#To save the emails in a subfolder
attachmentSavePath = r'D:\School\Docs\2171Code\Emails\Attachments'


#subject - The Subject of the email as a string
#keyWords - List with defined keywords to look for
def readEmailFromFile():
	for filename in os.listdir(savePath):
		if ".txt" in filename:
			completePath = os.path.join(savePath,filename)
			fp = open(completePath,"r")
			#data = f.read()
			for line in fp:
				if "Subject" in line:
					sub = line[9:]
					print(sub)
				if "Message from" in line:
					sendTo = line.split('<')
					sendTo = sendTo[1]	
					sendTo = sendTo.split('>')
			parseEmailSubject(sub,sendTo)
		else:
			continue				



def parseEmailSubject(subject,sendTo):
	hold = keyWords.keys()
	for word in hold:
		if word in subject:
			sendFormToClient(word,subject,sendTo)
			return 1
		
	sendFormToClient("Default",subject,sendTo)
	return -1

#TODO - Have if statements to send an email back to the user with the link to the correct form based on subject line
def sendFormToClient(key,subject,sendTo):
	
	#connect with Google's servers
	smtp_ssl_host = 'smtp.gmail.com'
	smtp_ssl_port = 465

	username = 'marlontestemail1@gmail.com'
	password = 'marlontest'

	from_addr = 'marlontestemail1@gmail.com'
	#hold = str(input("Please enter the email you wish to send the message to: "))
	to_addrs = [sendTo]

	if key in keyWords:
		#the email lib has a lot of templates for different message formats
		#on our case we will use MIMEText to only send text.
		msg = keyWords[key]
		print(msg)
		fullMessage = "This serves as a response to your email. Please fill out this form so we can serve you better. \n" + msg
		message = MIMEText(fullMessage)
		sub = "Response to "+ subject
		message['subject'] = sub
		message['from'] = from_addr
		message['to'] = ', '.join(sendTo)

		#we will connect using SSL
		server = smtplib.SMTP_SSL(smtp_ssl_host,smtp_ssl_port)

		#to interact with the server, first we log in and then we send the message

		server.login(username,password)
		server.sendmail(from_addr,to_addrs, message.as_string())
		print("Message sent as email to: " + str(to_addrs))
		server.quit()




#egreadEmailFromFile()

