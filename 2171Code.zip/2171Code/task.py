#from employee import *
import csvread
#import Category
#import status 


savePath = r"D:\School\Docs\2171Code\Emails\Tasks"

elst = ["fabric", "containers", "event"]
tlst = ["print","Print","Design","Cater", "design", "cater"]

class Status():

    status = "" 

    def __init__(self, typ=None):
        if typ is None or typ not in tlst:
            self.status = "Un-Opened"
        else:
            self.status = typ


    def setStatus(self):
        option = str(input("1 - Pending, 2 - In Progress , 3 - Complete"))
        if option == 1:
            self.status = "Pending"
        
        if option == 2:
            self.status = "In Progress"
        
        if option == 3:
            self.status = "Complete"
    
    def getStatus(self):
        return self.status

class category:
    #Attributes
	type = None   
	def __init__(self, typ=None):
	    if typ is None:
	        self.type = "Misc"
	    else:
	        self.type = typ

	def setCategory(self, newType):
	    self.type = newType

	def getCategory(self):
	    return self.type

	def __str__(self):
	    return "The overall category is --> ", self.type


class EmailCategory(category):

    def __init__(self, typ=None):
        if typ is None:
            super().__init__()
        elif typ in category.elst:
            super().__init__(typ)
        else:
            super().__init__()

    def __str__(self):
        return "The category of the Email is --> ", self.type


class TaskCategory(category):

	def __init__(self, typ=None):
		if typ is None:
			super().__init__()
		elif typ in tlst:
			super().__init__(typ)
		else:
			super().__init__()

	def __str__(self):
		return "The category of the Task is --> ", self.type

	def getKeywords(self):
		return tlst


class Employee:
    def __init__(self, nm, jbs=None):
        self.name = nm
        if jbs == None:
            self.jobs = []
        else:
            self.jobs = jbs

    def getName(self):
        return self.name

    def getJobs(self):
        tmp = []
        for tsk in self.jobs:
            tmp.append(tsk.toString())
        return tmp

    def taskAssignment(self, Task):
        self.jobs.append(Task)
        
        #if isinstance(Task, task):
         #   self.jobs.append(Task)
        #else:
         #   print("Input attribute is not Task type.")

    def removeTask(self, Task):
        self.jobs.remove(Task)

    def printTasks(self):
        for job in self.jobs:
            print(job.getCategory())

    @classmethod
    def isEmployee(cls, val):
        return isinstance(val, Employee)


class Manager(Employee):

    def __init__(self, nm):
        super().__init__(nm)

    def internalTaskAssignment(self, Task, employee):
        if employee.isEmployee():
            employee.taskAssignment(Task)
        else:
            print("Error, this is not an Employee!!!!")

    @classmethod
    def isManager(cls, val):
        return isinstance(val, Manager)

class Task:
    # Attributes
    category = None
    assignedEmployees = []
    taskStatus = Status()
    email = ""
    details = None

    
    # Initializer
    # This method creates a Task with attributes for Email,Category, employee and status
    def __init__(self, category, assignedEmployee, askStatus, email, emailBody):
        self.category = TaskCategory(category)
        self.assignedEmployees.append(assignedEmployee)
        self.taskStatus = askStatus
        self.email = email
        self.details = emailBody
        assignedEmployee.taskAssignment(self)

    # Methods
    def __str__(self):
        #return "Task Information:\nEmail of Customer: {}\nCategory: {} \nCurrent Status: {}.".format(self.email, self.category, self.taskStatus)
        return "Task Information:\nEmail of Customer: "+ self.email + "\nCategory: "+self.category.getCategory() + " Current Status: "+ self.taskStatus.getStatus() + "\nDetails of Task: "+self.details

    def toString(self):
        return "Task Information:\nEmail of Customer: "+ self.email + "\nCategory: "+self.category.getCategory() + " Current Status: "+ self.taskStatus.getStatus() + "\nDetails of Task: "+self.details
    # Getters
    def detailsExtraction(self):
        return self.details

    def getStatus(self):
        return self.taskStatus

    def getEmployees(self):
        return self.assignedEmployees

    def getCategory(self):
        return self.category

    def setStatus(self, newStatus):
        self.taskStatus = newStatus

    def addEmployee(self, employee):
        self.assignedEmployees.append(employee)
        employee.taskAssignment(self)


class SubTask(Task):
    subCategory = None
    lable = "Sub Task"

    def __init__(self, category, assignedEmployee, askStatus, email):
        super().__init__(category, assignedEmployee, askStatus, email)

def separateTasks(hold):
	data = []
	string = []
	s = ""
	#print(hold)
	for response in hold:
		for tup in response:
			if "Email" in tup[0]:
				h = [tup[0] + ": " + tup[1]]
				string.append(h)
			if "Full" in tup[0]:
				string.append(tup[1])
			if "Affiliated" in tup[0]:
				s += tup[0] + tup[1] + " "
			if "Type" in tup[0]:
				s += tup[0] + tup[1] + " "
			if "Details" in tup[0]:
				s += tup[0] + tup[1] + " "	
		string.append(s)
		data.append(string)
		s = ""
		string = []
	#print(data)
	return data

def createTask():   
    lst  = []
    temp = []
    hold = csvread.readDataFromFile()
    #print(hold)
    hold1 = separateTasks(hold)
    generatedTasks = []
    employee1 = Employee("K-Cyanne BeckFord")
    employee2 = Employee("Alana Thompson")
    manager1 = Manager("Lois-Anne Hall")

    for form in hold1:
        print("\n\n")
        print("Task to be assigned: ")
        formEmail = str(str(form[0]).split(":")[1]).split("'")[0]
        print("Email: " +formEmail)
        formName = form[1]
        print("Name of Client: " + formName)
        formDetails = form[2]
        print(formDetails) 
        formStatus = Status()
        print("\n")
        for word in tlst:#TaskCategory.getKeywords():
            if word in formDetails:
            	tCat = TaskCategory(word)
            	break
            else:
            	tCat = TaskCategory()
        option = int(input("Which Employee are you assigning this to. Enter 1 for K-Cyanne, Enter 2 for Alana: "))
        if option == 1:
            tsk = Task(tCat, employee1, formStatus, formEmail, formDetails)
        else:
            tsk = Task(tCat, employee2, formStatus, formEmail, formDetails)
        
        generatedTasks.append(tsk)
    print("\n\n")

   

    temp.append(employee1.getName())
    temp.append(employee1.getJobs())
    lst.append(temp)
    
    temp = []

    temp.append(employee2.getName())
    temp.append(employee2.getJobs())
    lst.append(temp)
    print("\n\nTasks have been assigned.")

    return lst
    


def viewAssignedTasks(lst):
    print("---------Viewing the Assigned Tasks-------------")
    print("\n\n")
    for employee in lst:
        print("Employee Name: " + employee[0])
        if employee[1] == []:
            print("No Tasks Assigned")
        else:
            for i in range(len(employee[1])):
                print("Employee Jobs: " + employee[1][i])
                print("\n")
        print("\n\n\n")
#createTask()

